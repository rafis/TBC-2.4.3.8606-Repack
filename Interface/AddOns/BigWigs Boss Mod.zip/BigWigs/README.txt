--Timers
Q. Why are some timers off? I seem to have timers like Maiden of Virtue Repentance innacurate.
A. A lot of bosses have what we call 'Cooldown Abilities', what we are timing is the cooldown of the ability, 
so the boss can use the ability any time after the cooldown is over

Q. Is there an easy way to recognise these cooldowns?
A. Usually we use a '~' on front of timers that are not exact(approximations), or we will specify its a cooldown 
in the bar/warning


--PVP
Q. Why is there not some kind of pvp timers in Big Wigs?
A. Simple, we don't believe pvp timers belong in a boss mod, we encourage users that want pvp timers to try the 
mod 'Capping' available at files.wowace.com


--Trash
Q. Can we get some kind of respawn timers in Big Wigs?
A. No, there is a separate mod for respawn timers called 'Incubator' available at files.wowace.com