# Questie Alpha
**A quest helper for World of Warcraft (2.4.3) - The Burning Crusade**

**Special NOTE:** Questie TBC is not in active development currently. This branch is only here for archival purposes. If you want to use it anyway, please be aware that this is an Alpha version! The client works just fine without issue in The Burning Crusade expansion. The quest database however hasn't been updated with TBC quests yet. All pre-BC quests are working so you shouldn't have any problems if you plan on leveling through Vanilla content before hitting TBC content.

