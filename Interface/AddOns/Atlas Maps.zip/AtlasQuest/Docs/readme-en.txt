

AtlasQuest
Maintained by Thandrenn (aka Mystery8)
Email me at mystery8@gmail.com
Forums at http://www.atlasmod.com/phpBB3/viewforum.php?f=7



About AtlasQuest:
=================

AtlasQuest is an addon for Atlas or AlphaMap that displays a list of 
quests for each dungeon, battleground and outdoor raid along with 
information and rewards for those quests. 

AtlasQuest was originally created by Asurn. It is currently maintained
by Thandrenn (aka Mystery8).



Translations:
=============

EN: Thandrenn  (previously Asurn and Lothaer)
DE: Telchar and Nalumis  (previously Asurn and Nihlo)
CN: yeachan  (previously DIY)



License:
========

AtlasQuest is released under the GNU General Public License (GPL).
For the full license text please see: gpl-v2-en.txt
